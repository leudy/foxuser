var __wpo = {
  "assets": {
    "main": [
      "/cdd4d23968460981453c46d565472261.svg",
      "/912ec66d7572ff821749319396470bde.svg",
      "/fee66e712a8a08eef5805a46892932ad.woff",
      "/a2cf84ebfd4b4a5b17f5cd7b221c784a.jpg",
      "/b5b8fbf1d8c84c9dca2bc26259d15efb.jpg",
      "/674f50d287a8c48dc19ba404d20fe713.eot",
      "/b06871f281fee6b241d60582ae9369b9.ttf",
      "/af7ae505a9eed503f8b8e6982036873e.woff2",
      "/runtime.1e66c1691d5d04774ff1.js",
      "/"
    ],
    "additional": [
      "/npm.lodash.pick.6c1e7520557a6cf47bae.chunk.js",
      "/npm.mousetrap.d710cfd428db5c0dd67a.chunk.js",
      "/npm.sweetalert.b1f56d44f8e41b092cdc.chunk.js",
      "/npm.sweetalert-react.1a75300376fe15011c90.chunk.js",
      "/npm.joi-browser.aae26ed38ae5b853aeca.chunk.js",
      "/npm.performance-now.f2b6f1ea957fb666b74a.chunk.js",
      "/npm.raf.6fac8ce414cbc72cf514.chunk.js",
      "/npm.webpack.b7c12f1a4d33c5e623a9.chunk.js",
      "/npm.lodash.4df2ca3d518e28f956cc.chunk.js",
      "/9.b035190e1c1bbd6f18a0.chunk.js",
      "/npm.emotion.316e5f094bb10d59bfd8.chunk.js",
      "/11.fcbeeb0dc938cc7ce459.chunk.js",
      "/12.4156c4f301414048ac01.chunk.js",
      "/13.7c9c3b75edaf5be22f63.chunk.js",
      "/npm.apexcharts.668ff62f64ccb982ea68.chunk.js",
      "/npm.intl.aa5071b4fdd0148db571.chunk.js",
      "/npm.react-apexcharts.978d5e6a851f682bfcde.chunk.js",
      "/npm.react-scrollbar.3aa22324ebfe5dd42d7a.chunk.js",
      "/npm.setimmediate.afed5cb2c794bf55cdc1.chunk.js",
      "/npm.timers-browserify.ba3966d3b91ec3db9c57.chunk.js",
      "/20.9c5014bd4112dac2d663.chunk.js",
      "/main.1425fd2150dfd0e6bf49.chunk.js",
      "/npm.babel.e2ec73ea14375ffd776e.chunk.js",
      "/npm.connected-react-router.f88e089a026a507a5aa8.chunk.js",
      "/npm.font-awesome.9cee99697ecc6b7f617b.chunk.js",
      "/npm.material-ui.ad27d75dc6d034a3cf8b.chunk.js",
      "/npm.react-app-polyfill.55d40938ea2723580c53.chunk.js",
      "/npm.react-redux.f2924fc534b9a1eb7e63.chunk.js",
      "/npm.redux-saga.9fa81d8f8a93952c9b97.chunk.js",
      "/30.4674806e72dc9faba993.chunk.js",
      "/31.c620d7e9249e69f0d5bb.chunk.js",
      "/32.11d3dcbcf26766459909.chunk.js",
      "/33.695ee18b3e260872be04.chunk.js",
      "/34.4ebc0192826688c43903.chunk.js",
      "/35.05d1798e2fb232b4fde8.chunk.js",
      "/36.6279adeaa856cdeabc52.chunk.js",
      "/37.4263200c1e8097030b0a.chunk.js",
      "/38.b01ea392e6f7b330c21f.chunk.js",
      "/39.6a53803903887da8b8df.chunk.js",
      "/40.fbf5dd0f004304351b78.chunk.js",
      "/41.5a79b09b12ce3afe4292.chunk.js",
      "/42.1114c70ede71bc88bd4a.chunk.js",
      "/43.e76ee83d5720222bdba5.chunk.js",
      "/44.5d198ef5cbd6e4dff552.chunk.js",
      "/45.c7f75b50e0e5993dfd68.chunk.js",
      "/46.934a0393b0c7e78eef08.chunk.js",
      "/47.45045289ee71c471fc85.chunk.js",
      "/48.3da427948064792c9748.chunk.js",
      "/49.43afbaf38df346c38ac4.chunk.js",
      "/50.256788b939aac6b355c4.chunk.js",
      "/51.f455bb64930f8901e39f.chunk.js",
      "/52.9528857eea8ff148909b.chunk.js",
      "/53.c690b099dd2c4702db31.chunk.js",
      "/54.d34f87381c36c7cc7033.chunk.js",
      "/55.11dc9f3e59bcfe7197c7.chunk.js",
      "/56.c87654f49b50ce4d0e53.chunk.js",
      "/57.446cf95ed90bd652b074.chunk.js",
      "/58.1cacdfc532207ab26c8f.chunk.js",
      "/59.15419b1d3d22f0e03de6.chunk.js",
      "/60.23f6d82af2f69dca9b0e.chunk.js",
      "/61.97e05649a4c421a2e061.chunk.js",
      "/62.994b0047912c1a212eac.chunk.js",
      "/63.15638558abbbf93c5a1a.chunk.js",
      "/64.db9b34296d9551567d96.chunk.js",
      "/65.064cc92e58706ca50180.chunk.js",
      "/66.b60c429a1fb756ed3b7e.chunk.js",
      "/67.6de4bfd8c140d908393c.chunk.js",
      "/68.97a938da43cddecabc99.chunk.js",
      "/69.a3447e373685980e3801.chunk.js",
      "/70.c247f41a87e0a4cf4172.chunk.js",
      "/71.d6ef864a1afb431347f4.chunk.js",
      "/72.62371114d569e6fbd560.chunk.js",
      "/73.298b15f3b1ca694ed23a.chunk.js",
      "/74.6686b67bc05998566dce.chunk.js",
      "/75.5ab0dafaf9dac7d57199.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "29f3aaded2ea8ae6b30439f3802cd47815ce6331": "/cdd4d23968460981453c46d565472261.svg",
    "98a8aa5cf7d62c2eff5f07ede8d844b874ef06ed": "/912ec66d7572ff821749319396470bde.svg",
    "28b782240b3e76db824e12c02754a9731a167527": "/fee66e712a8a08eef5805a46892932ad.woff",
    "147301ffbf0886c7196d39d88c108408a65d3626": "/a2cf84ebfd4b4a5b17f5cd7b221c784a.jpg",
    "4146a5ca978d19810cf163c74486a7596983abc1": "/b5b8fbf1d8c84c9dca2bc26259d15efb.jpg",
    "d980c2ce873dc43af460d4d572d441304499f400": "/674f50d287a8c48dc19ba404d20fe713.eot",
    "13b1eab65a983c7a73bc7997c479d66943f7c6cb": "/b06871f281fee6b241d60582ae9369b9.ttf",
    "d6f48cba7d076fb6f2fd6ba993a75b9dc1ecbf0c": "/af7ae505a9eed503f8b8e6982036873e.woff2",
    "f56a532ff07ff8b11513fd68f85296f068ffe9db": "/npm.lodash.pick.6c1e7520557a6cf47bae.chunk.js",
    "0856559760b0892ccf7fc9703c381786f79bae75": "/npm.mousetrap.d710cfd428db5c0dd67a.chunk.js",
    "aa0ed07538860b2494a0f7c1eece6fa5e2ad933d": "/npm.sweetalert.b1f56d44f8e41b092cdc.chunk.js",
    "bdc9b0a077db4480f0504df83a2e2e04967e5a82": "/npm.sweetalert-react.1a75300376fe15011c90.chunk.js",
    "717b2346600aa9476ce4edea46a61a098d9ec1ae": "/npm.joi-browser.aae26ed38ae5b853aeca.chunk.js",
    "bc602e45862e47f6220ec814a8c9c996e3690ef6": "/npm.performance-now.f2b6f1ea957fb666b74a.chunk.js",
    "20b7ccee97d1087901ef73eb133f4300b39691a0": "/npm.raf.6fac8ce414cbc72cf514.chunk.js",
    "b81930b42c97d043e7d133c6b9c56a74c77e677c": "/npm.webpack.b7c12f1a4d33c5e623a9.chunk.js",
    "9c0c858fae8b1c619bd389257b45e4c48ea94226": "/npm.lodash.4df2ca3d518e28f956cc.chunk.js",
    "db45355c0e476226fb8a246f87ee864e2e8cc08f": "/9.b035190e1c1bbd6f18a0.chunk.js",
    "21a1d5ea9a5f55dabaa2d5a555c359f23f5792c9": "/npm.emotion.316e5f094bb10d59bfd8.chunk.js",
    "a39afc9ba5390accbd9b454e1e11e1c15247f21c": "/11.fcbeeb0dc938cc7ce459.chunk.js",
    "00e4317541074984ce03a65825fd9cd4af72c197": "/12.4156c4f301414048ac01.chunk.js",
    "b70e73585ce4323d401d43b45a1ca57862c10a5f": "/13.7c9c3b75edaf5be22f63.chunk.js",
    "43f9d9f3c8e4b6a45df772b5221f1ed560bade7b": "/npm.apexcharts.668ff62f64ccb982ea68.chunk.js",
    "ef983483821b0112408de6fa11772617d6e70ba2": "/npm.intl.aa5071b4fdd0148db571.chunk.js",
    "3c7ba212fbed63ab9d13d74731785d933e194c00": "/npm.react-apexcharts.978d5e6a851f682bfcde.chunk.js",
    "51f5787f1331c6820a9d00c24498956b3078a5e4": "/npm.react-scrollbar.3aa22324ebfe5dd42d7a.chunk.js",
    "838f412f12ae8fa9d9ce0f85f6c9ac771a78fc99": "/npm.setimmediate.afed5cb2c794bf55cdc1.chunk.js",
    "e08a8694bb0bb4a666b20d53769dbe1c8c1b60c7": "/npm.timers-browserify.ba3966d3b91ec3db9c57.chunk.js",
    "de8c7980147f6776a660b4cdad3ced8bb0a33a7f": "/20.9c5014bd4112dac2d663.chunk.js",
    "2a4d9de2d0592279cf4896a187f022ce09269cce": "/main.1425fd2150dfd0e6bf49.chunk.js",
    "d3d9acd0404bc2a9a153be31de329e8ceee64292": "/npm.babel.e2ec73ea14375ffd776e.chunk.js",
    "3de9044515b146fe7c19188d28b7215406c89192": "/npm.connected-react-router.f88e089a026a507a5aa8.chunk.js",
    "60fea2b7a5f9ac4c8acdc26ddd86876279016efa": "/npm.font-awesome.9cee99697ecc6b7f617b.chunk.js",
    "b86a760890e5bdc328e13abf8be6c1ec66c26401": "/npm.material-ui.ad27d75dc6d034a3cf8b.chunk.js",
    "7b581a5402206bd493ea761438026e2204d45f15": "/npm.react-app-polyfill.55d40938ea2723580c53.chunk.js",
    "7c9f51f0b985ef35089b7517e717d9ee7ae024a8": "/npm.react-redux.f2924fc534b9a1eb7e63.chunk.js",
    "70c51a46dfb82e6a914ebf288b08bc95a656c285": "/npm.redux-saga.9fa81d8f8a93952c9b97.chunk.js",
    "c645dcb6f6760b84890e20845243035c280db215": "/runtime.1e66c1691d5d04774ff1.js",
    "2a0d23ecd92576807caf27d3d5cb7b2fb402fb52": "/30.4674806e72dc9faba993.chunk.js",
    "a02f38508e98eb089ea01fca977cbc4b860ed4e6": "/31.c620d7e9249e69f0d5bb.chunk.js",
    "878ae57d19bbc68525578fd16f25893c1bb6086b": "/32.11d3dcbcf26766459909.chunk.js",
    "54d9991238af3fbea059e9d0f4717c748647edc6": "/33.695ee18b3e260872be04.chunk.js",
    "ccbeeae284de29f93ba74ed0b7d89c31819580cc": "/34.4ebc0192826688c43903.chunk.js",
    "80dea13e42e1bf00453e72562f3704f12d553701": "/35.05d1798e2fb232b4fde8.chunk.js",
    "af0cb90c3c5eb94c75ddab25753d55e4f9e8d0a7": "/36.6279adeaa856cdeabc52.chunk.js",
    "1c084bfd8822a36b8c39746d4f2d09e953073171": "/37.4263200c1e8097030b0a.chunk.js",
    "1543bb315895f9fb2eadeb6b97450833a2803f14": "/38.b01ea392e6f7b330c21f.chunk.js",
    "0d32788087dd4b8bca526fabdc471d0d9d99edce": "/39.6a53803903887da8b8df.chunk.js",
    "d86213af0182a0f34ca5cb14fb4cc41ad5e2858a": "/40.fbf5dd0f004304351b78.chunk.js",
    "79f862909a0fb4a716102894f2f7bd20582bdc61": "/41.5a79b09b12ce3afe4292.chunk.js",
    "214147addcd97a3c988ab9e47276bed441f2c8c7": "/42.1114c70ede71bc88bd4a.chunk.js",
    "1ebd5b0b716b8c6b60257db921403a1156cf4f79": "/43.e76ee83d5720222bdba5.chunk.js",
    "0757bca686245c2a61ff48230ddda3e3cefcdad6": "/44.5d198ef5cbd6e4dff552.chunk.js",
    "6c8355609084fcbc6a7d6ef38408c40a8bc251ee": "/45.c7f75b50e0e5993dfd68.chunk.js",
    "bab87ef303bec0285a6b9938188696571f97fdce": "/46.934a0393b0c7e78eef08.chunk.js",
    "d2e60f1113c9e1943ed39bded6271949a2820462": "/47.45045289ee71c471fc85.chunk.js",
    "2817e0844156fcce4c81d746bf3e2e0103fdea74": "/48.3da427948064792c9748.chunk.js",
    "3d750a2fcc198d2143f17d1a58f3c66253cc506e": "/49.43afbaf38df346c38ac4.chunk.js",
    "185097d7ee0b9038a613c12320d948d0fb5418c1": "/50.256788b939aac6b355c4.chunk.js",
    "40d97084767149fdb85b5e9b43e681728f710e8b": "/51.f455bb64930f8901e39f.chunk.js",
    "3d4201f2851168fbd89893d7b9e8df12c6bbdba1": "/52.9528857eea8ff148909b.chunk.js",
    "cca9facbef8317d696905da0e30f9de3cf2fc30d": "/53.c690b099dd2c4702db31.chunk.js",
    "ca4bc070cac82702fde7ff703172ed86fe2d4fcd": "/54.d34f87381c36c7cc7033.chunk.js",
    "25655f9a69c962c2fcf1ffb74399a5e78b2508ba": "/55.11dc9f3e59bcfe7197c7.chunk.js",
    "0c8b621cdf201e8a415f8ce4ca3a9594f78f7472": "/56.c87654f49b50ce4d0e53.chunk.js",
    "cd9d49bb8eb2173f30f86fca7fede359d8828fba": "/57.446cf95ed90bd652b074.chunk.js",
    "f46f819ab73026a42192b3c6a81f1c7c4e4af9b5": "/58.1cacdfc532207ab26c8f.chunk.js",
    "a3b92d0c7c04fdb9c14cae70d028453e903f5d5e": "/59.15419b1d3d22f0e03de6.chunk.js",
    "04ce0b25711bd1bf7b4de39d3e4ddfa3d5f824fd": "/60.23f6d82af2f69dca9b0e.chunk.js",
    "1d8d8d25c8f6e59b626e6743d2015ce38b04c629": "/61.97e05649a4c421a2e061.chunk.js",
    "e8da0fbfb8fb8b61bba0d6611034c99912b1863f": "/62.994b0047912c1a212eac.chunk.js",
    "1419e900b7185fc3dee85759911a118524ef8d6c": "/63.15638558abbbf93c5a1a.chunk.js",
    "55d24b9db5469f44bee9f3763064484072a7442e": "/64.db9b34296d9551567d96.chunk.js",
    "47fa531663377e93f37474e1409e7d4df00c8b13": "/65.064cc92e58706ca50180.chunk.js",
    "6d0b452d5d9b7a0e99414de7bb074e38c9e0999f": "/66.b60c429a1fb756ed3b7e.chunk.js",
    "8a7e496c1293b49fa09eafbf8f2b67f2b384a101": "/67.6de4bfd8c140d908393c.chunk.js",
    "59549a779059caea6f2e521cfe5e3bfdd078b5f3": "/68.97a938da43cddecabc99.chunk.js",
    "64f5a2a257b5423fa3a5e622aea0e7aa28783939": "/69.a3447e373685980e3801.chunk.js",
    "8f69cd02c6be84c2ff7fe6ac56e589ea5841e571": "/70.c247f41a87e0a4cf4172.chunk.js",
    "2efd802d6c0d45e99272c3afa08d95ac4edaad86": "/71.d6ef864a1afb431347f4.chunk.js",
    "b62f51c776f311ba81aed9ee41ca8cb4801d398d": "/72.62371114d569e6fbd560.chunk.js",
    "b5827050bdfae497f69c6363f4d27b7717324755": "/73.298b15f3b1ca694ed23a.chunk.js",
    "86e2aa9febe7a2f78601667e3b94d23276eab108": "/74.6686b67bc05998566dce.chunk.js",
    "2d0a2572e4acc4e4f4166be2e5039ca316bee1b5": "/75.5ab0dafaf9dac7d57199.chunk.js",
    "7f8a6efde8975683c3a5eb2e46060daf588acf02": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "1/15/2022, 12:04:37 AM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });